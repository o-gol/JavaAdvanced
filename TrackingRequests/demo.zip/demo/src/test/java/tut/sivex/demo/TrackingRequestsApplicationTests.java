package tut.sivex.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingRequestsApplicationTests {

	@Test
	void contextLoads() {
	}

}
